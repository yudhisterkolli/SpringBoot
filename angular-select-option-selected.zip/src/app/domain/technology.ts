export class Technology { 
    constructor(public techId:number, public techName:string) {
    }
}