import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthenticationComponent } from './components/authentication/authentication.component';
import { HomeComponent } from './components/home/home.component';
import { HeaderComponent } from './components/header/header.component';
import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';
import { EmployeeComponent } from './components/employee/employee.component';
import { AuthGuard } from './AuthGuard';
import { EmployeeDetailsComponent } from './components/employee-details/employee-details.component';
import { EmployeeAddOreditComponent } from './components/employee-add-oredit/employee-add-oredit.component';
import { UpdateEmployeeComponent } from './components/update-employee/update-employee.component';

const routes: Routes = [
  { path: "header",
   component:HeaderComponent},
  { path: "home", component:HomeComponent},
  { path: "login",component: AuthenticationComponent},   
  { path: 'employee-list', component: EmployeeComponent,
    children: [
    {
      path:'employee-details/:id', component: EmployeeDetailsComponent
    },
    {
      path:'employee-add', component: EmployeeAddOreditComponent
    },
    {
      path:'employee-update/:id', component: UpdateEmployeeComponent
    } 

  ], canActivate: [AuthGuard] },
  /*{ path: 'employee-details/:id', component: EmployeeDetailsComponent},*/
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: '**', component: PageNotFoundComponent }

];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
