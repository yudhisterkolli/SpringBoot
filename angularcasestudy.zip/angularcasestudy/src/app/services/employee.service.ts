import { Injectable } from '@angular/core';
import { Observable, observable } from 'rxjs';
import { RestApiService } from '../Database/rest-api.service';
import { Employee } from '../Database/employee';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { retry, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  employeeData: any = {};
  Employee: any = [];
  dataList: Employee[] = [];
  constructor(public restApi: RestApiService) {

   }
     
  addEmployee(employee : Employee){
   /*let length = this.employeeList.length; 
   employee.empId = length+1;
   this.employeeList.push(employee);*/
  }

  deleteEmployee(id:number){
   /* let i : number ;
    this.employeeList.forEach((value,index)=>{
      if(value.empId==id) this.employeeList.splice(index,1);
    });*/
    this.restApi.deleteEmployee(id).subscribe((data) => {
      this.getAllEmployees();
    });
  }

  updateEmployee(employee : Employee){    
    /*this.employeeList.forEach(element => {
      if(element.empId == employee.empId){
        this.employee = element;
        element.empId = employee.empId;
        element.firstName= employee.firstName;
        element.lastName =  employee.lastName;
        element.email= employee.email;
        element.phoneNumber = employee.phoneNumber;
      }
     });*/
     this.restApi
     .updateEmployee(employee.empId, this.employeeData)
     .subscribe((data) => {      
     });
 

  }
   
  loadEmployees() {
    return this.restApi.getEmployees().subscribe((data: {}) => {
     console.log(data);
    });
  }

  parseData(jsonData: string) {
    //considering you get your data in json arrays
    for (let i = 0; i < jsonData[1].length; i++) {
         const data = new Employee();
         data.firstName=jsonData[1][i];
         data.lastName=jsonData[2][i];
         data.email=jsonData[3][i];
         data.phoneNumber=12345678;
         data.empId = 1;
         this.dataList.push(data);
    }
  }

  getAllEmployees(){             
    return this.restApi.getEmployees().subscribe((data: {}) => {
      this.Employee = data;
    });
  }

   /* getEmployeeById(id:number): Observable<Employee>{
       this.employeeList.forEach(element => {
         if(element.empId == id){
          this.employee = element;
         }
        });   
        return this.employee;
      }*/
  getEmployeeById1(id:number){
  }

  public getEmployeeById(id:number): Employee  { 
    /*this.employeeList.forEach(element => {
      if(element.empId == id){
       this.employee = element;
      }
     });
     console.log(this.employee);*/
     this.restApi.getEmployee(id).subscribe((data: {}) => {
      this.employeeData = data;
    });
    
    return  this.employeeData; 
  };


}
