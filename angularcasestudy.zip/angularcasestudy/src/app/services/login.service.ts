import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor() { }

  //validate username and password
  login(userName:string, password:string){
    //console.log(userName, password);
    //if(userName.match("admin") && password.match("password"))return true;
    //else return false;
    localStorage.setItem('currentUser', userName);
    return true;

  }

  
  public isLoggedIn(){
    return localStorage.getItem('currentUser') !== null;

  }

  public logout(){
    localStorage.removeItem('currentUser');
  }

}
