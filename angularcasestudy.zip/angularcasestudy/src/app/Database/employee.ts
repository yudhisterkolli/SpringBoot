export class Employee  { 
  firstName: string;
  lastName: string;
  email:string;
  phoneNumber: number;
  empId: number;

  Employee(){ }

 
}
