import { Component, OnInit } from '@angular/core';
import { Employee } from 'src/app/Database/employee';
import { EmployeeService } from 'src/app/services/employee.service';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';

@Component({
  selector: '',
  templateUrl: './employee-details.component.html',
  styleUrls: ['./employee-details.component.css']
})
export class EmployeeDetailsComponent implements OnInit {
  empId: number;
  employee: Employee;
  constructor(private route: ActivatedRoute, private router: Router, private employeService: EmployeeService) { }

  ngOnInit(): void {
    this.empId = this.route.snapshot.params['id'];
    this.getEmpDetails(this.empId);
  }

  getEmpDetails(empId:number)
  {
     // this.employee = this.employeService.getEmployeeById(empId);
      //alert(this.employee.empId)
     // console.log(this.employee);
      
  }

}
