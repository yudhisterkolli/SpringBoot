import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppRoutingModule } from 'src/app/app-routing.module';
import { AuthenticationComponent } from '../authentication/authentication.component'; 
import { ViewChild } from '@angular/core';
import { User } from '../entity/User';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  loggedInUserName : String;
  @ViewChild(AuthenticationComponent)
  private  authcomp:AuthenticationComponent;
  ngAfterViewInit() {
     //this.getLoggedInUser();
  }
  getLoggedInUser() {
    this.loggedInUserName =  this.getUser();
     //alert(this.loggedInUserName);
  }
  getUser(): any {
    return localStorage.getItem('currentUser');
  }

  constructor(private router: Router) { }

  ngOnInit(): void {
    this.getLoggedInUser();
  }

  logout(){   
    localStorage.removeItem('currentUser');
    this.router.navigate(['/login'])
  }

}
