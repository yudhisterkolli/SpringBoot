import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/services/login.service';
import { User } from '../entity/User';
import { Input } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './authentication.component.html',
  styleUrls: ['./authentication.component.css']
})
export class AuthenticationComponent implements OnInit {

  loginForm:  FormGroup;
  public user = new User();
  loggedInUser:string;
  submitted = false;
 
  constructor(private router: Router, private loginService:LoginService) { 

  }
 
  ngOnInit(): void {
    this.createLoginForm();
  }

  createLoginForm(){
      this.loginForm = new FormGroup({
      username: new FormControl('',Validators.required),
      password: new FormControl('',Validators.required)    
    });
  }
  resetForm(){
    this.loginForm.reset();
    this.submitted = false;
  }

  login(){        
    if (this.loginForm.valid) {
       this.submitted = true;
       console.log(this.loginForm.value);
       localStorage.setItem("user-Data", JSON.stringify(this.loginForm.value));   
       console.log(this.formControls.username.value);    
      if(this.loginService.login(this.formControls.username.value, this.formControls.password.value)){   
        this.loggedInUser = this.formControls.username.value;      
            this.router.navigateByUrl('/home');
        }else { 
             this.router.navigateByUrl('/login')        
        }; 
      }else if (!this.loginForm.valid){
         this.router.navigateByUrl('/login')    
      }
  }

  logout(){
    this.router.navigate(['/login']);
   }

     // convenience getter for easy access to form fields
  get formControls() { return this.loginForm.controls; }

  get email() { return this.loginForm.controls.userName.value; }

  
}
