import { Component, OnInit } from '@angular/core';
import { EmployeeService } from 'src/app/services/employee.service';
import { Router } from '@angular/router';
import { Employee } from 'src/app/Database/employee';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {


  //empList: Employee[];
  empList : any = [];
  emp : Employee;

  constructor(private router: Router,private empService: EmployeeService) { }

  ngOnInit( ): void {
     this.getEmpList();

  }

  getEmpList(){
     this.empList = this.empService.loadEmployees();     
     console.log(this.empList);
  }

   deleteEmployee(id:number){
      this.empService.deleteEmployee(id);    
      this.router.navigate(['/employee-list']);
   }

   addEmployee(){
      this.router.navigate(['employee-add']);
   }

   updateEmployee(empId:number){
      this.router.navigate(['/employee-list/employee-update',empId]);
   }

   getEmployee(id:number){    
         this.router.navigate(['/employee-list/employee-details', id]);
   }
  }
