import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeAddOreditComponent } from './employee-add-oredit.component';

describe('EmployeeAddOreditComponent', () => {
  let component: EmployeeAddOreditComponent;
  let fixture: ComponentFixture<EmployeeAddOreditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EmployeeAddOreditComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeAddOreditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
