import { Component, OnInit } from '@angular/core';
import { Employee } from 'src/app/Database/employee';
import { EmployeeService } from 'src/app/services/employee.service';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { Form, FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { Validators } from '@angular/forms';


@Component({
  selector: 'app-employee-add-oredit',
  templateUrl: './employee-add-oredit.component.html',
  styleUrls: ['./employee-add-oredit.component.css']
})
export class EmployeeAddOreditComponent implements OnInit {

  employee: Employee;
  addOrEditForm: FormGroup;
  submitted : boolean = false;
  
  constructor(private formBuilder: FormBuilder,private route: ActivatedRoute, private router: Router, private employeService: EmployeeService){

  }

  ngOnInit(): void {
    let employeeId = this.route.snapshot.params['id'];
    if(employeeId != null){
     this.employee=this.employeService.getEmployeeById(employeeId);      

    }
    this.createAddOrEditForm();
  }

  createAddOrEditForm(){
    this.addOrEditForm = new FormGroup({
      firstName: new FormControl('',Validators.required),
      lastName: new FormControl('',Validators.required),
      email: new FormControl('',Validators.required) ,
      phoneNumber: new FormControl('',Validators.required)      
    });
  }
  onSubmit(){
    console.log(this.addOrEditForm.value);
    this.submitted = true;
    console.log(this.addOrEditForm.valid)
    if(this.addOrEditForm.valid){
       this.employee = this.addOrEditForm.value;
     // this.employeService.addEmployee(this.employee);
      this.addOrEditForm.reset();
      this.router.navigate(['employee-list']);
    }
  }

  get formControls() { return this.addOrEditForm.controls; }

  resetFrom(){
    this.addOrEditForm.reset();
  }

  createFormGroupWithBuilder(formBuilder: FormBuilder) {
    return formBuilder.group({
      employeeData: formBuilder.group({
        email: 'yudhister@email.com',
        firstName: '',
        lastName: ''
      }),
      requestType: '',
      text: ''
    });
  }

 
}
