import { Component, OnInit } from '@angular/core';

import { EmployeeService } from 'src/app/services/employee.service';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { Form, FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { Validators } from '@angular/forms';
import { Employee } from 'src/app/Database/employee';


@Component({
  selector: 'app-update-employee',
  templateUrl: './update-employee.component.html',
  styleUrls: ['./update-employee.component.css']
})
export class UpdateEmployeeComponent implements OnInit {
  public employee: Employee;
  addOrEditForm: FormGroup;
  submitted : boolean = false;
  
  constructor(private formBuilder: FormBuilder,private route: ActivatedRoute, private router: Router, private employeService: EmployeeService){

  }

  ngOnInit(): void {
    this.createAddOrEditForm();
    let employeeId = this.route.snapshot.params['id'];
    if(employeeId != null){
     // this.employee=this.employeService.getEmployeeById(employeeId);      

    }
    
  }

  createAddOrEditForm(){
    this.addOrEditForm = new FormGroup({
      firstName: new FormControl('',Validators.required),
      lastName: new FormControl('',Validators.required),
      email: new FormControl('',Validators.required) ,
      phoneNumber: new FormControl('',Validators.required)      
    });
  }
  onSubmit(){
    console.log(this.addOrEditForm.value);
    this.submitted = true;
    console.log(this.addOrEditForm.valid)
    if(this.addOrEditForm.valid){
       this.employee = this.addOrEditForm.value;
     // this.employeService.updateEmployee(this.employee);     
      this.router.navigate(['employee-list']);
    }
  }

  get formControls() { return this.addOrEditForm.controls; }

  resetFrom(){
    this.addOrEditForm.reset();
  }
 
}
