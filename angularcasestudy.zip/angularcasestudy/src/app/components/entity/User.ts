export class User{
    public  username : String;
}