package com.fis.ms.book.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fis.ms.book.entities.Book;

public interface BookRepo extends JpaRepository<Book, String>{

	  
}
