package com.fis.ms.book.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fis.ms.book.entities.Book;
import com.fis.ms.book.repo.BookCrudRepo;
import com.fis.ms.book.repo.BookRepo;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.ratelimiter.RequestNotPermitted;
import io.github.resilience4j.ratelimiter.annotation.RateLimiter;


@RestController
@RequestMapping("/book-api")
public class BookController {
	
	@Autowired
	BookRepo bookrepo;
	
	@Autowired
	BookCrudRepo bkcrdrepo;

	@Autowired
	Environment envi;
	String port_name = "local.server.port";
	
	Logger logger = LoggerFactory.getLogger(BookController.class);
	
	
	@RequestMapping(path="/api/books")
	//Retry ( CircuitBreaker ( RateLimiter ( TimeLimiter ( Bulkhead ( Function ) ) ) ) )
	@CircuitBreaker(name = "getBooks", fallbackMethod = "getBooksFallback")
    public List<Book> getAllBooks()
	{
		logger.info("BOOK-SERVICE-GET-ALL-BOOKS-CALLED...!" + envi.getProperty(port_name));
		return bookrepo.findAll();
		
	}

	 public List<Book> getBooksFallback(Exception e) {
		 logger.info("---RESPONSE FROM FALLBACK METHOD---");
		 List<Book> li = new ArrayList<Book>();
		 Book b = new Book();
         b.setAuthor("SERVICE IS DOWN, PLEASE TRY AFTER SOMETIME !!!");
         li.add(b);
         return li;
      }
	  
	@RequestMapping(path="/api/checkavail")
	 @RateLimiter(name = "getMessageRateLimit", fallbackMethod = "checkAvailFallBack")
	public String getBookAvailability(@RequestParam(name = "name") Optional<String> queryParam)
	{
		logger.info("PORT-CALLED:"+envi.getProperty(port_name));
	
			if(queryParam.isPresent())
			{
				Long avail_count = bookrepo.findAll().stream().filter(bk -> bk.getBook_id().equalsIgnoreCase(queryParam.get()))
						                                     .filter(bk -> bk.getAvailable_copies() > 0).count();
				if (avail_count > 0)return "BOOK AVAILABLE";
           				
			}
			return "BOOK NOT AVAILABLE"; 
	}
	
	  public String checkAvailFallBack(RequestNotPermitted exception) {

		  logger.info("Rate limit has applied, So no further calls are getting accepted");

          return ResponseEntity.status(HttpStatus.TOO_MANY_REQUESTS)
          .body("Too many requests : No further request will be accepted. Please try after sometime").getBody().toString();
      }
	@RequestMapping(path="/api/upbkavail")
	public String addBookAvailability(@RequestParam(name = "id") Optional<String> queryParam)
	{
		logger.info("PORT-CALLED:"+envi.getProperty(port_name));
	
			if(queryParam.isPresent())
			{
				List<Book> book = bookrepo.findAll().stream().filter(bk -> bk.getBook_id().equalsIgnoreCase(queryParam.get()))
						                               .collect(Collectors.toList());
				int count = 0;
				int add_count = 0;
				for(Book b : book)
				{
					count = b.getAvailable_copies();
				}
				add_count = count + 1;
				System.out.println("COPIES:"+count);
				
				int result = bkcrdrepo.updateAvailability(add_count, queryParam.get());
				logger.info("UPDATE-RESULT:"+result);							
           				return result ==1 ? "AVAILABLE COUNT INCREASED" : "ERROR IN AVAILABLE COUNT INCREMENT";
			}
			return "BOOK ID NOT PROVIDED"; 
	}
	
	@RequestMapping(path="/api/delbkavail")
	public String delBookAvailability(@RequestParam(name = "id") Optional<String> queryParam)
	{
		logger.info("PORT-CALLED:"+envi.getProperty(port_name));
	
			if(queryParam.isPresent())
			{
				List<Book> book = bookrepo.findAll().stream().filter(bk -> bk.getBook_id().equalsIgnoreCase(queryParam.get()))
						                               .collect(Collectors.toList());
				int count = 0;
				int del_count = 0;
				for(Book b : book)
				{
					count = b.getAvailable_copies();
				}
				del_count = count - 1;
				logger.info("COPIES:"+count);
				
				int result = bkcrdrepo.updateAvailability(del_count, queryParam.get());
				logger.info("DELETE-RESULT:"+result);							
           				return result ==1 ? "AVAILABLE COUNT DECREASED" : "ERROR IN AVAILABLE COUNT DECREMENT";
			}
			return "BOOK ID NOT PROVIDED"; 
	}
}
