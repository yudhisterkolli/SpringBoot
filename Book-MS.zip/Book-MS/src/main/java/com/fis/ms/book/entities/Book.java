package com.fis.ms.book.entities;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor
@AllArgsConstructor
public @Data class Book {

	@Id
	private String book_id;
	private String book_name;
	private String author;
	private int available_copies;
	private int total_copies;
}
