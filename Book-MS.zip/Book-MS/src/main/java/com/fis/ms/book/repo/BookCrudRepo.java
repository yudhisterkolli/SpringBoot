package com.fis.ms.book.repo;

import java.math.BigDecimal;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.fis.ms.book.entities.Book;

@Repository
public interface BookCrudRepo extends JpaRepository<Book, Long> {

	@Transactional
	@Modifying
	@Query("UPDATE Book SET AVAILABLE_COPIES = :AVAILABLE_COPIES WHERE book_id = :book_id")
	Integer updateAvailability(int AVAILABLE_COPIES, String book_id);

	//void updateAvailability(int add_count, String book_id);
}

