package com.fis.ms.book;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookMicroServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
