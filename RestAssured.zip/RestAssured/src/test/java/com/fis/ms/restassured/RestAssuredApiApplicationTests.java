package com.fis.ms.restassured;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestAssuredApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
