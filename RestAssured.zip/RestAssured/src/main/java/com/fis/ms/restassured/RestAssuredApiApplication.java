package com.fis.ms.restassured;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestAssuredApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestAssuredApiApplication.class, args);
	}

}
