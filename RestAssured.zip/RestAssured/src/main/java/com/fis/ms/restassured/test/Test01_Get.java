package com.fis.ms.restassured.test;

import static io.restassured.RestAssured.*;
import static java.util.concurrent.TimeUnit.MILLISECONDS;
import org.hamcrest.Matchers.*;

public class Test01_Get {

	public static void getResponseBody(){
		   given().when().
		           .get("http://localhost:2200/book-api/api/books")
		          .then()
		          .log()
		           .all();
		 
		}
	
}
