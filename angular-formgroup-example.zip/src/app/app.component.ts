import { Component } from '@angular/core';
import {FormControl, Validators} from '@angular/forms';

@Component({
   selector: 'app-root',
   template: `
			   <app-form-group></app-form-group>
	         `
})
export class AppComponent { 
}
    