package com.fis.ms.subs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SubsMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
