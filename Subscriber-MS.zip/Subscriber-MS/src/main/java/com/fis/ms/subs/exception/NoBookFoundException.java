package com.fis.ms.subs.exception;

public class NoBookFoundException extends RuntimeException {

	private String message;
	public NoBookFoundException() {
		
	}

	public NoBookFoundException(String message) {
		super(message);
		this.message = message;
	}

	

}
