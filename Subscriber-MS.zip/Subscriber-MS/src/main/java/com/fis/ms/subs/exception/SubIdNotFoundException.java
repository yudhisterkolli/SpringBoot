package com.fis.ms.subs.exception;

public class SubIdNotFoundException extends Exception {

	private String message;
	
	public SubIdNotFoundException()
	{
		
	}
	
	public SubIdNotFoundException(String message)
	{
		super(message);
		this.message = message;
	}
}
