package com.fis.ms.subs.bean;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
public @Data class BookProxy {

	private String book_id;
	private String book_name;
	private String author;
	private int available_copies;
	private int total_copies;
}
