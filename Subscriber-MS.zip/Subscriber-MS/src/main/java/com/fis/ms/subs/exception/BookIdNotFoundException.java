package com.fis.ms.subs.exception;

public class BookIdNotFoundException extends RuntimeException{

	
	private String message;
	
	public BookIdNotFoundException()
	{
		
	}
	public BookIdNotFoundException(String message)
	{
		super(message);
		this.message=message;
	}
}
