package com.fis.ms.subs.proxy;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import com.fis.ms.subs.bean.BookProxy;

@FeignClient(name="book-service")
public interface BookServiceProxy {

	@GetMapping("/book-api/api/books")
	public List<BookProxy> findByAll();
}
