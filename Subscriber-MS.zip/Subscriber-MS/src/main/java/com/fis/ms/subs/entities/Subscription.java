package com.fis.ms.subs.entities;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor
@AllArgsConstructor
public @Data class  Subscription {
	
	@Id
	private String SUBSCRIBER_NAME;
	private String BOOK_ID;
	private Date DATE_SUBSCRIBED;
	private Date DATE_RETURNED;
	

}
