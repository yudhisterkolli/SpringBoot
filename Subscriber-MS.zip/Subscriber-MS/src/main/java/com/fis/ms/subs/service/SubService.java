package com.fis.ms.subs.service;

import java.util.List;

import com.fis.ms.subs.bean.BookProxy;
import com.fis.ms.subs.entities.Subscription;
import com.fis.ms.subs.exception.BookNotFoundException;
import com.fis.ms.subs.exception.NoBookFoundException;
import com.fis.ms.subs.exception.NoSubNotFoundException;
import com.fis.ms.subs.exception.SubIdNotFoundException;
import com.fis.ms.subs.exception.SubscriberNotFoundException;

public interface SubService {

	Subscription findById(String name) throws SubIdNotFoundException;
	List<Subscription> findAll() throws NoSubNotFoundException;
	List<BookProxy> findByAll() throws NoBookFoundException;
	String findByName(String name) throws BookNotFoundException;
	Subscription saveAndFlush(Subscription subscriber) throws SubscriberNotFoundException;
}
