package com.fis.ms.subs.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fis.ms.subs.entities.Subscription;
import com.fis.ms.subs.exception.NoSubNotFoundException;
import com.fis.ms.subs.exception.SubIdNotFoundException;
import com.fis.ms.subs.exception.SubscriberNotFoundException;
import com.fis.ms.subs.repo.SubsRepo;
import com.fis.ms.subs.service.SubService;

@RestController
@RequestMapping("/sub-api")
public class SubsController {
    
	@Autowired
 	SubsRepo subrepo;
	
	@Autowired
	SubService subservice;
	
	@Value("${server.port}")
    private String port;
	/*
	 * @RequestMapping(path="/subss") public List<Subscription> getSubs() {
	 * 
	 * return subrepo.findAll();
	 * 
	 * }
	 * 
	 * @RequestMapping(path="/sub") public Optional<Subscription>
	 * getSubswithParams(@RequestParam(name = "name") Optional<String> queryParam) {
	 * 
	 * return queryParam.isPresent() ? subrepo.findById(queryParam.get()) :
	 * Optional.empty();
	 * 
	 * 
	 * }
	 */
	
	@RequestMapping(path="/api/subs")
	public ResponseEntity getAllSubs() throws NoSubNotFoundException
	{
		
	  return new ResponseEntity(subservice.findAll(),HttpStatus.OK);

	}

	@RequestMapping(path="/api/sub",produces="application/json")
	public ResponseEntity findById(@RequestParam(name = "name") String queryParam) throws SubIdNotFoundException
	{
		
	   return new ResponseEntity(subservice.findById(queryParam), HttpStatus.OK);

	}
	
	@RequestMapping(path="/api/allbooks")
	public ResponseEntity findByAll() throws NoSubNotFoundException
	{
		
	  return new ResponseEntity(subservice.findByAll(),HttpStatus.OK);

	}
	
	@RequestMapping(path="/api/isbookavail")
	public ResponseEntity findByName(@RequestParam(name = "id") String id) throws NoSubNotFoundException
	{
		
	  return new ResponseEntity(subservice.findByName(id),HttpStatus.OK);

	}
	
	@PostMapping(path="/api/addsub")
	public ResponseEntity addSubscriber(@RequestBody Subscription sub) throws SubscriberNotFoundException
	{
		
	  return new ResponseEntity(subservice.saveAndFlush(sub),HttpStatus.CREATED);

	}

	
}
