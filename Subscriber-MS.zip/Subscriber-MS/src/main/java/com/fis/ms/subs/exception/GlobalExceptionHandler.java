package com.fis.ms.subs.exception;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {

	
	@Value(value = "${data.exception.message1}")
    private String message1;

	@Value(value = "${data.exception.message2}")
    private String message2;
	
	@Value(value = "${data.exception.message3}")
    private String message3;
	
	@Value(value = "${data.exception.message4}")
    private String message4;
	
	@Value(value = "${data.exception.message5}")
    private String message5;
    
    @SuppressWarnings("rawtypes")
	@ExceptionHandler(value = SubIdNotFoundException.class)
    public ResponseEntity SubIdNotFoundException(SubIdNotFoundException subIdNotFoundException) {
        return new ResponseEntity(message1, HttpStatus.OK);
    }
    
	@SuppressWarnings("rawtypes")
	@ExceptionHandler(value = NoSubNotFoundException.class)
    public ResponseEntity NoSubNotFoundException(NoSubNotFoundException noSubNotFoundException) {
        return new ResponseEntity(message2, HttpStatus.OK);
    }
	
	@SuppressWarnings("rawtypes")
	@ExceptionHandler(value = NoBookFoundException.class)
    public ResponseEntity NoBookFoundException(NoBookFoundException noBookNotFoundException) {
        return new ResponseEntity(message3, HttpStatus.OK);
    }
	
	@SuppressWarnings("rawtypes")
	@ExceptionHandler(value = BookNotFoundException.class)
    public ResponseEntity BookNotFoundException(BookNotFoundException bookNotFoundException) {
        return new ResponseEntity(message4, HttpStatus.UNPROCESSABLE_ENTITY);
    }
	
	@SuppressWarnings("rawtypes")
	@ExceptionHandler(value = SubscriberNotFoundException.class)
    public ResponseEntity SubscriberNotFoundException(SubscriberNotFoundException subNotFoundException) {
        return new ResponseEntity(message5, HttpStatus.UNPROCESSABLE_ENTITY);
    }
}
