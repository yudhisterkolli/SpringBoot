package com.fis.ms.subs.controller;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fis.ms.subs.bean.BookProxy;
import com.fis.ms.subs.exception.BookIdNotFoundException;

@RestController
public class ConsumeBookService {

	String books_base_url = "http://localhost:2222/api/books";
	String books_avail_url ="http://localhost:2222/api/checkavail?name=";
	@Autowired
	RestTemplate resttemplate;
	
	@RequestMapping(value = "/books")
	   public List<BookProxy> getProductList() {
	      
	     Object[] objects = resttemplate.getForEntity(books_base_url, Object[].class).getBody();
	     ObjectMapper mapper = new ObjectMapper();
	     
	     return Arrays.stream(objects)
	    		  .map(object -> mapper.convertValue(object, BookProxy.class))
	    		  .collect(Collectors.toList());

	   }
	
			
	@RequestMapping(value = "/books1")
	   public String getProductList1() {
	      HttpHeaders headers = new HttpHeaders();
	      headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
	      HttpEntity <String> entity = new HttpEntity<String>(headers);
	      
	      
	    return resttemplate.exchange(books_base_url, HttpMethod.GET, entity, String.class).getBody();
	   }
	
	@RequestMapping(value = "/checkavail")
	   public String checkAvail(@RequestParam(name = "name") Optional<String> queryParam) {
				
		if(queryParam.isPresent())
		{
			  HttpHeaders headers = new HttpHeaders();
		      headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		      HttpEntity <String> entity = new HttpEntity<String>(headers);
		      
		      
		    String result = resttemplate.exchange(books_avail_url+queryParam.get(), HttpMethod.GET, entity, String.class).getBody();
		    if(result.equalsIgnoreCase("BOOK AVAILABLE"))
		    {
		    	return "BOOK AVAILABLE";
		    }
		    else if(result.equalsIgnoreCase("BOOK NOT AVAILABLE"))
		    {
		    	throw new BookIdNotFoundException();
		    }
			
       				
		}
		return "BOOK ID NOT PROVIDED"; 

	   }
}
