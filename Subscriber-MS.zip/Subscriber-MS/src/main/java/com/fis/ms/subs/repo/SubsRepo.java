package com.fis.ms.subs.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fis.ms.subs.entities.Subscription;

public interface SubsRepo extends JpaRepository<Subscription, String>{
	
	//Optional<Subscription> findById(String name);

}
