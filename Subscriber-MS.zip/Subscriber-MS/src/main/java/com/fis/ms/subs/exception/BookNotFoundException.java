package com.fis.ms.subs.exception;

public class BookNotFoundException extends RuntimeException {

	private String message;
	public BookNotFoundException() {
		// TODO Auto-generated constructor stub
	}

	public BookNotFoundException(String message) {
		super(message);
		this.message = message;
	}



}
