package com.fis.ms.subs.exception;

public class NoSubNotFoundException extends RuntimeException{

	
	private String message;
	
	public NoSubNotFoundException()
	{
		
	}
	public NoSubNotFoundException(String message)
	{
		super(message);
		this.message=message;
	}
}
