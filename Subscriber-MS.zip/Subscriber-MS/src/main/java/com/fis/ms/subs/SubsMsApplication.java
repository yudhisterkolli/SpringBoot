package com.fis.ms.subs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients("com.fis.ms.subs")
@EnableEurekaClient
public class SubsMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SubsMsApplication.class, args);
	}

}
