package com.fis.ms.subs.exception;

public class SubscriberNotFoundException extends RuntimeException {

	private String message;
	
	public SubscriberNotFoundException(String message)
	{
		super(message);
		this.message = message;
	}
	public SubscriberNotFoundException()
	{
		
	}
}
