package com.fis.ms.subs.impl;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fis.ms.subs.bean.BookProxy;
import com.fis.ms.subs.entities.Subscription;
import com.fis.ms.subs.exception.BookNotFoundException;
import com.fis.ms.subs.exception.NoBookFoundException;
import com.fis.ms.subs.exception.NoSubNotFoundException;
import com.fis.ms.subs.exception.SubIdNotFoundException;
import com.fis.ms.subs.exception.SubscriberNotFoundException;
import com.fis.ms.subs.proxy.BookServiceProxy;
import com.fis.ms.subs.repo.SubsRepo;
import com.fis.ms.subs.service.SubService;

@Service
public class SubServiceImpl implements SubService{

	@Autowired
	private SubsRepo subrepo;
    
	@Autowired
	private RestTemplate resttemplate;
	
	@Autowired
	private BookServiceProxy proxy;

	String books_base_url = "http://localhost:2222/book-api/api/books";
	String books_avail_url ="http://localhost:2222/book-api/api/checkavail?id=";
	String books_del_url ="http://localhost:2222/book-api/api/delbkavail?id=";

	
@Override
public Subscription findById(String name) throws SubIdNotFoundException {
	
	Subscription subList;
	
	if(subrepo.findById(name).isPresent())
	{
		subList = subrepo.findById(name).get();
	}
	else
	{
		throw new SubIdNotFoundException();
	}
	 
	
	return subList;
}

@Override
public List<Subscription> findAll() throws NoSubNotFoundException {
	
	List<Subscription> subs ;
	if(subrepo.findAll().isEmpty())
	{
		throw new NoSubNotFoundException();
	}
	else
	{
		 subs = subrepo.findAll();
	}
	return subs;
}

@SuppressWarnings("unused")
@Override
public List<BookProxy> findByAll() throws NoBookFoundException {

	List<BookProxy> books ;
		books = proxy.findByAll();     
     
     if(books.isEmpty())
     {
    	 throw new NoBookFoundException();
     }
     else 
     {
    	 return books;
     }
	
}

@Override
public String findByName(String name) throws BookNotFoundException {

	HttpHeaders headers = new HttpHeaders();
    headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
    HttpEntity <String> entity = new HttpEntity<String>(headers);
	String result = resttemplate.exchange(books_avail_url+name, HttpMethod.GET, entity, String.class).getBody();
	if("BOOK AVAILABLE".equalsIgnoreCase(result))
	{
		return result;
	}
	else
	{
		throw new BookNotFoundException();
	}
}

@Override
public Subscription saveAndFlush(Subscription subscriber) throws SubscriberNotFoundException {
	
	
	HttpHeaders headers = new HttpHeaders();
    headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
    HttpEntity <String> entity = new HttpEntity<String>(headers);
	String result = resttemplate.exchange(books_del_url + subscriber.getBOOK_ID(), HttpMethod.GET, entity, String.class).getBody();
	Subscription sub;
	if("AVAILABLE COUNT DECREASED".equalsIgnoreCase(result))
	{
		sub = subrepo.saveAndFlush(subscriber);
		if(sub.getBOOK_ID().isEmpty())
		{
			throw new SubscriberNotFoundException();
		}
		else 
		{
			return sub;
		}
	}
	else
	{
		throw new SubscriberNotFoundException();
	}
	
}


}
