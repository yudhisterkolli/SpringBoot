package com.fis.ms.api.route;

import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class GatewayRouting {
	
	 @Bean
	    public RouteLocator configureRoute(RouteLocatorBuilder builder) {
	       return builder.routes()
	      .route("subId", r->r.path("/sub-api/**").uri("http://localhost:5555")) //static routing
	      .route("bookId", r->r.path("/book-api/**").uri("lb://book-service")) //dynamic routing
	      .build();
	    }

}
